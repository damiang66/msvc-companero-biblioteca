package com.companeros.msvclibro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsvcLibroApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsvcLibroApplication.class, args);
	}

}
