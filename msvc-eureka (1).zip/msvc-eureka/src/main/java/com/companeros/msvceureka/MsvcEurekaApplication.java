package com.companeros.msvceureka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsvcEurekaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsvcEurekaApplication.class, args);
	}

}
