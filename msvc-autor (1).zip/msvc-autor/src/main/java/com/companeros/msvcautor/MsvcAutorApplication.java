package com.companeros.msvcautor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsvcAutorApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsvcAutorApplication.class, args);
	}

}
